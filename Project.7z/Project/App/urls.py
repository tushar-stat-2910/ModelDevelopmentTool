from django.urls import path
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings  # Import settings
from django.conf.urls.static import static  # Import static for media files
import pandas as pd
import io
from. import views

from django.urls import path

urlpatterns = [
    path('', views.WelcomePage, name='WelcomePage'),  # Home page route
    path('DataUpload/', views.DataUpload, name='DataUpload'),# DataUpload page route When we want to use DataUpload button this route execute
    path('FileUpload/', views.FileUpload, name='DataUpload'),# DataUpload function route when javascript fech data this route executed
    path('GetColumns/',views.GetColumns, name = 'GetColumns'),
    path('DataExploration/', views.DataExploration, name='DataExploration'),
    path('DataExploration/summary-statistics/', views.summary_statistics, name='summary_statistics'),
    path('DataExploration/feature-2-2/', views.feature_2_2, name='feature_2_2'),
    path('DataExploration/feature-2-3/', views.feature_2_3, name='feature_2_3'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)