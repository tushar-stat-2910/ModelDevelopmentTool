from django.core.files.storage import FileSystemStorage
import pandas as pd
from .forms import FileUploadForm
from django.http import JsonResponse
import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt


def WelcomePage(request):                                       # This is an Home View Once app Is started
     return render(request, "App/WelcomePage.html")

def DataUpload(request):
    return render(request, "App/DataUpload.html")
    

@csrf_exempt
def FileUpload(request):
    if request.method == "POST" and request.FILES.get("file"):
        uploaded_file = request.FILES["file"]
        save_path = f"media/uploads/{uploaded_file.name}"

        try:
            with open(save_path, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            return JsonResponse({"success": True})
        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)})

    return JsonResponse({"success": False, "error": "No file uploaded."})


def DataExploration(request):
    return render(request, 'App/data_exploration.html')



# def GetColumns(request):
#     #file_path = os.path.join(settings.MEDIA_ROOT, "uploaded_data.csv")  # Adjust path if needed
#     file_path = "./media/uploads/data 2.csv"
#     if not os.path.exists(file_path):
#         return JsonResponse({"error": "No file found"}, status=400)
    
#     try:
#         df = pd.read_csv(file_path)  # Adjust for Excel if needed
#         columns = df.columns.tolist()
#         return JsonResponse({"columns": columns})
#     except FileNotFoundError:
#         try:
#             df = pd.read_excel(file_path)  # Adjust for Excel if needed
#             columns = df.columns.tolist()
#             return JsonResponse({"columns": columns})
#         except Exception as e:
#             return JsonResponse({"error": str(e)}, status=400)


def summary_statistics(request):
    return render(request, 'App/summary_statistics.html')

def feature_2_2(request):
    return render(request, 'App/feature_2_2.html')

def feature_2_3(request):
    return render(request, 'App/feature_2_3.html')




# # This is an Upload Data View
# def upload_file(request):
#     return 0

# # Store the uploaded data in memory




# def data_upload(request):
#     return render(request, 'App/data_upload.html')

