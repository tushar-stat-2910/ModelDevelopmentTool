from django import forms

class FileUploadForm(forms.Form):
    InputData = forms.FileField(label="Upload your file")
