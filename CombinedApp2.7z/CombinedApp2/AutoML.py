import pandas as pd
import numpy as np
import os
from datetime import datetime, date, time, timezone
import sys
import pickle as pkl
from Hyperparameter import *
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer
from sklearn.model_selection import GridSearchCV 
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.decomposition import PCA
from sklearn.metrics import confusion_matrix
import json
import logging
logging.basicConfig(filename="logfile2.log", level=logging.INFO)

def AutoML(settings_dict, df_train, df_test = None):
    # settings_dict = {
    #                 'imp_dict': {'Income_': 'mean', 'Gender_': 'mode', 'Age_': 'mean', 'WorkingYears_': 'mean', 'Education_': 'mode', 'Location_': 'mode', 'FunctionOfIncomeAndAge_': 'mean', 'BureauScore_': 'mean'},
    #                 'ohe_cols': ['Gender_', 'Education_', 'Location_'], 'target_col': 'y_', 
    #                 'hyperParamDict': {AdaBoostClassifier(): {'clf__learning_rate': [0.01, 0.1], 'clf__n_estimators': [100, 150]}, GradientBoostingClassifier(): {'clf__learning_rate': [0.01], 'clf__n_estimators': [50, 75, 100], 'clf__max_depth': [2, 3], 'clf__min_samples_split': [2], 'clf__min_samples_leaf': [2]}, RandomForestClassifier(): {'clf__n_estimators': [100], 'clf__criterion': ['gini'], 'clf__min_samples_split': [2], 'clf__min_samples_leaf': [2]}, BalancedRandomForestClassifier(n_jobs=-1): {'clf__n_estimators': [100], 'clf__criterion': ['gini'], 'clf__min_samples_split': [2], 'clf__min_samples_leaf': [2]}, KNeighborsClassifier(n_jobs=-1): {'clf__n_neighbors': [5], 'clf__weights': ['distance']}, SVC(probability=True): {'clf__C': [100], 'clf__tol': [0.005], 'clf__kernel': ['sigmoid']}, LogisticRegression(multi_class='multinomial', solver='newton-cg'): {'clf__C': [2000], 'clf__tol': [0.0001]}}
    # }


    imp_dict = settings_dict['imp_dict']
    ohe_cols = settings_dict['ohe_cols']
    target_col = settings_dict['target_col']
    clfs = settings_dict['hyperParamDict']
    
    imp_dict = pd.Series(imp_dict)

    blankFillWithMean_features = list(imp_dict.loc[imp_dict == "mean"].index)
    blankFillWithMedian_features = list(imp_dict.loc[imp_dict == "median"].index)
    blankFillWithMode_features = list(imp_dict.loc[imp_dict == "mode"].index)
    blankIsBlank_features = list(imp_dict.loc[imp_dict == "BLANK"].index)
    blankIsZero_features = list(imp_dict.loc[imp_dict == 0].index)

    imputation_list_num =   [('blankIsZero', SimpleImputer(missing_values=np.nan, strategy='constant', fill_value = 0), blankIsZero_features),
                             ('blankFillWithMean', SimpleImputer(missing_values=np.nan, strategy='mean'), blankFillWithMean_features),
                             ('blankFillWithMedian', SimpleImputer(missing_values=np.nan, strategy='median'), blankFillWithMedian_features)]

    imputation_list_cat =   [('blankIsBlank', SimpleImputer(missing_values=np.nan, strategy='constant', fill_value = 'blank'), blankIsBlank_features),
                             ('blankFillWithMode', SimpleImputer(missing_values=np.nan, strategy='most_frequent'), blankFillWithMode_features),
                           ]

    numeric_features = []
    for x in imputation_list_num:
        for y in (x[2]):
            numeric_features.append(y)

    categorical_features = []
    for x in imputation_list_cat:
        for y in (x[2]):
            categorical_features.append(y)


    imp_num = ColumnTransformer(imputation_list_num,remainder='drop')
    imp_cat = ColumnTransformer(imputation_list_cat,remainder='drop')

    numeric_transformer = Pipeline(steps = [('imp_num', imp_num),
                                #('reconstructionToPandasDataFrame1', pandasDataFrameReconstruction(columns= numericalCols)),
                                ('scaler', StandardScaler())
                               ])

    categorical_transformer = Pipeline(steps = [('imp_cat', imp_cat),
                                #('reconstructionToPandasDataFrame2', pandasDataFrameReconstruction(columns= catCols)),
                                ('ohe',OneHotEncoder(handle_unknown='ignore'))
                               ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_features),
            ('cat', categorical_transformer, categorical_features),
            ],
        remainder='drop')


    #df_train = pd.read_csv("./inputFile.csv")    
    X_train = df_train.drop([target_col], axis =1)
    y_train = df_train.loc[:,target_col]
    
    if df_test is not None:
        test_results = pd.DataFrame()
        test_results["y_act"] = df_test.loc[:,target_col]
        
    #trained_clfs = []
    trained_clfs = {}
    #trained_clfs_dict = {}
    cv_results = pd.DataFrame()
    
    for clf, param_grid in clfs.items():
        pipe = Pipeline(steps=[('preprocessor', preprocessor),
                               ('clf', clf)])
        search = GridSearchCV(pipe, param_grid, n_jobs=-1, scoring = {'AUC': 'roc_auc', 'Precision': 'precision','Recall':'recall','F1 Score':'f1','Accuracy':'accuracy'}, refit = 'AUC')
        search.fit(X_train, y_train)
        
        
        #with open('model_pkl2', 'wb') as files:
            #pkl.dump(model, files)
            
        temp_df = pd.DataFrame(search.cv_results_)
        temp_df["Algorithm"] = inv_clf_lookup_dict[clf]
        temp_df['params'] = temp_df['params'].astype('str')
        #trained_clfs.append(search)
        trained_clfs[inv_clf_lookup_dict[clf]] = search
        cv_results = pd.concat([cv_results, temp_df], axis = 0)
        
        #logging.info(temp_df["Algorithm"]
        if df_test is not None:
            X_test = df_test.drop([target_col], axis =1)
            y_pred = search.best_estimator_.predict_proba(X_test)
            y_pred = pd.DataFrame(y_pred)[1]
            test_results[inv_clf_lookup_dict[clf]] = y_pred
    
    #logging.info(trained_clfs)
    #trained_clfs = json.dumps(trained_clfs)
    #with open('model_pkl2', 'wb') as files:
            #pkl.dump(trained_clfs, files)
    
    #for i in range(0, len(trained_clfs)):
        #trained_clfs_dict[i] = trained_clfs[i]
    #print(trained_clfs_dict) 
    return trained_clfs, cv_results, test_results
