style_data_conditional=[
        {
            'if': {
                'column_id': ['InputOrTarget', 'Imputation', 'List of values to try','Encoding'],
            },
            'backgroundColor': '#2CA02C',
            'color': 'white'
        }
  ]

tabs_styles = {
    'height': '44px'
}
tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '6px',
    'fontWeight': 'bold'
}

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#119DFF',
    'color': 'white',
    'padding': '6px'
}

uploadStyle = {'width': '100%','height': '60px','lineHeight': '60px','borderWidth': '1px','borderStyle': 'dashed','borderRadius': '5px','textAlign': 'center','margin': '10px'}

sideColStyle = {"width": "300px", "height": "525px",'margin': '10px','padding':'10px'}