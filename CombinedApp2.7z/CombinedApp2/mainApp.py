
##########################################################################################################################################################################################################################

import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output
import dash.dcc as dcc
import dash.html as html

# Import layouts from external apps
from dashApp import layout as classification_layout
from ClusterApp import layout as clustering_layout  # Renamed from 'app.py'

app = dash.Dash(__name__, suppress_callback_exceptions=True)

app.layout = html.Div([
    html.Div([
        html.Button("Classification", id="classification-btn", n_clicks=0),
        html.Button("Clustering", id="clustering-btn", n_clicks=0),
    ]),
    html.Div(id='page-content')  # Dynamically updates the content
])

@app.callback(
    Output('page-content', 'children'),
    [Input('classification-btn', 'n_clicks'),
     Input('clustering-btn', 'n_clicks')]
)
def display_page(classification_clicks, clustering_clicks):
    ctx = dash.callback_context  # Get context of the callback

    if not ctx.triggered:
        return html.H3("Welcome! Click a button to load an app.")

    button_id = ctx.triggered[0]['prop_id'].split('.')[0]  # Identify the last clicked button

    if button_id == "classification-btn":
        return classification_layout
    elif button_id == "clustering-btn":
        return clustering_layout

    return html.H3("Welcome! Click a button to load an app.")

# def fileViewerComp():
#     return html.Div([
#         dcc.Upload(id='upload-data', children=html.Div(['Drag and Drop or ', html.A('Select Files')]),
#                    style=uploadStyle, multiple=False),
#         dash_table.DataTable(id='upload-data-table',
#                              columns=None,
#                              data=None,
#                              persistence=True)
#     ])

if __name__ == '__main__':
    app.run_server(debug=True)

