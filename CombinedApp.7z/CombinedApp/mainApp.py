import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output

# Import layouts from external apps
#from dashApp import layout as classification_layout
from dashApp import app as classification_app

#from app import layout as clustering_layout
from ClusterApp import app as clustering_app
app = dash.Dash(__name__, suppress_callback_exceptions=True)

from dashApp import layout as classification_layout
from ClusterApp import layout as clustering_layout  # Updated import name

app.layout = html.Div([
    html.Div([
        html.Button("Classification", id="classification-btn", n_clicks=0),
        html.Button("Clustering", id="clustering-btn", n_clicks=0),
    ]),
    html.Div(id='page-content')  # Dynamically updates the content
])

@app.callback(
    Output('page-content', 'children'),
    [Input('classification-btn', 'n_clicks'),
     Input('clustering-btn', 'n_clicks')]
)
def display_page(classification_clicks, clustering_clicks):
    if classification_clicks > 0:
        return classification_layout
    elif clustering_clicks > 0:
        return clustering_layout
    return html.H3("Welcome! Click a button to load an app.")

if __name__ == '__main__':
    app.run_server(debug=True)
